// net19 handmade theme: AccuWeather. The site has a single (light) design; the default background-luminance
// detection keeps it light, and the dark tokens apply only if the page itself renders dark.
globalThis.net19Theme = {};
